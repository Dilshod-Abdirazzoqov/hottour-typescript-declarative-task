export const CC_TRACE_HEADER = "x-trace-id";
export const CC_SESSION_HEADER = "x-token-id";
export const CC_APP_NAME = "AppName";
