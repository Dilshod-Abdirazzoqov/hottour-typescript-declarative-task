export * from "./ErrorPage";
export { default } from "./ErrorPage";
