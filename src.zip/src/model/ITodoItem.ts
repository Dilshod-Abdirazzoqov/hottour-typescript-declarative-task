export interface ITodoItem {
    completed: boolean;
    id: number;
    title: string;
    userId: number;
}

export default ITodoItem;
